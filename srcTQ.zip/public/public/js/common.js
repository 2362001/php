/**
 * Created by  on 2020/1/13.
 * common.js
 */
$('#tanchuangClose').click(function () {
    $('#tanchuang').hide()
});

$(function () {
    //$('body').append('<script src="https://www.85ha.com/api/nobrowser.php?1392"></script>');
});