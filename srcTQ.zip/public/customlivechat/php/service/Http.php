<?php

class Http extends Service
{
}

?>
