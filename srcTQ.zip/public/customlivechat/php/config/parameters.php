<?php

return array (
  'dbHost' => 'localhost',
  'dbPort' => '3306',
  'dbUser' => 'www_zyfxw_cc',
  'dbPassword' => 'bwRr3PXafKi5H6r',
  'dbName' => 'www_zyfxw_cc',
  'superUser' => 'admin',
  'superPass' => 'admin01',
  'services' => 
  array (
    'mailer' => 
    array (
      'smtp' => '',
      'smtpSecure' => 'ssl',
      'smtpHost' => '',
      'smtpPort' => '465',
      'smtpUser' => '',
      'smtpPass' => '',
    ),
  ),
  'appSettings' => 
  array (
    'contactMail' => 'admin@admin',
  ),
);

?>