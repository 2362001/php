//==============================================================================
//
//  Shared file
//
//==============================================================================

(function(app, config, $)
{
    app.SharedFileModel = Backbone.Model.extend({

        // ...
    });

})(window.Application, window.chatConfig, jQuery);
